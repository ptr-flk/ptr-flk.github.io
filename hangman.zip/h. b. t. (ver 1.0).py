# Hangman, but there are too many words
import os

# Preparations
targets = []
print("Hangman needs more words!")
n = int(input("Number of the English words: "))
for i in range(n):
    targets.append(input("Word " + str(i + 1) + " is: ").upper())
chance = int(input("Number of wrong answers required for Hangman to die: "))
print()

# Print the information before the game starts
print("Information:")
for i in range(n):
    print(str(i + 1) + ". " + targets[i] + "\t" + "Word length: " + str(len(targets[i])))
print("Chances: " + str(chance))
print()
input("Press any key to continue:")
os.system("cls")

# Create a "list" for the game
hangman = []
for i in range(n):
    hangman.append("_" * len(targets[i]))

# The main part...
print("========== HANGMAN ==========")
while True:
    if chance == 0:
        print("Hangman died because of your wrong answers. Hope he will have a better life in the paradise. :)")
        break
    if hangman == targets:
        print("Congratulations! You saved Hangman!")
        break
    # Print the words in hangman[]
    for i in range(len(hangman)):
        print(str(i + 1) + ".", end = " ")
        for j in hangman[i]:
            print(j, end = " ")
        print()
    # Deal with the letter player guess
    guess = input("Your guess (1 letter): ")
    guess = guess[0].upper()
    # Search for the letter
    flag = False
    for i in range(len(targets)):
        if guess in targets[i]:
            flag = True
            break
    # Judgement
    if flag:
        print("Your guess is right!")
        for i in range(len(targets)):
            for j in range(len(targets[i])):
                if guess == targets[i][j]:
                    temp = []
                    for k in range(len(hangman[i])):
                        temp.append(hangman[i][k])
                    temp[j] = guess
                    tempr = "".join(map(str, temp))
                    hangman[i] = tempr
    else:
        chance -= 1
        print("Your guess is not right! Now you have " + str(chance) + " chance(s) to guess.")
    print()

# End
print("Hangman chose these words:")
for i in range(len(targets)):
    print(str(i + 1) + ". " + targets[i])
input()
