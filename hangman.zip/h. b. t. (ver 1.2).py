# Hangman, but there are too many words...
# What's more, you can guess a whole word now...
# More and more, you can guess a part of a word, too!

import os

# Ask for the words that need players to guess
print("Hangman needs more words!")
n = int(input("Number of the English words: "))
targets = []
for i in range(n):
    targets.append(input("Word " + str(i + 1) + " is: ").upper())
chance = int(input("Number of wrong answers required for Hangman to die: "))
print()

# Print the information before the game starts
print("Information:")
for i in range(n):
    print(str(i + 1) + ". " + targets[i] + "\t" + "Word length: " + str(len(targets[i])))
print("Chances: " + str(chance))
print()
input("Press [Enter] to continue:")
os.system("cls")

# Create the list hangman[] filled with "_"
hangman = []
for i in range(n):
    hangman.append([])  # Create a list for every word
    for j in range(len(targets[i])):
        hangman[i].append("_")
guessed = []

# Functions used in the game loop:
def display_word(word_list):
    for i in range(len(word_list)):
        print(str(i + 1) + ".", end = " ")
        for j in word_list[i]:
            print(j, end = " ")
        print()

def display_guessed(ans_list):
    if len(ans_list) > 0:
        print("You have already guessed these:", end = " ")
        for i in ans_list:
            print(i, end = " ")
        print()
            
def get_guess():
    return input('Your guess ("~" for a part of the word): ').upper()

# New: "~" for a part of the word!    
def is_guessed(letter):
    if letter in guessed:
        print("You have already guessed this letter! Try another one.")
        return True
    else:
        if len(letter) != 0:
            if letter[0] == "~":
                letter = letter[2:]
            guessed.append(letter)
        return False

def judgement(answer, target_list):
    if len(answer) == 0:
        return None
    elif len(answer) == 1:
        for i in range(len(target_list)):
            if answer in target_list[i]:
                return True
        return False
    else:
        if answer[0] == "~":
            answer = answer[2:]
            for i in range(len(target_list)):
                if answer in target_list[i]:
                    return True
        else:
            for i in target_list:
                if answer == i:
                    return True
        return False
    
def update(answer, word_list, target_list):
    if len(answer) == 1:
        for i in range(len(target_list)):
            for j in range(len(target_list[i])):
                if answer == target_list[i][j]:
                    word_list[i][j] = answer
    else:
        if answer[0] == "~":
            answer = answer[2:]
            for i in range(len(target_list)):
                for j in range(len(target_list[i])):
                    if answer == target_list[i][j : j + len(answer)]:                          
                        for k in range(len(answer)):
                            word_list[i][j + k] = answer[k]
                        break
        else:
            for i in range(len(target_list)):
                if answer == target_list[i]:
                    word_list[i] = list(answer)
                
def combine(word_list):
    combination = []
    for i in range(len(word_list)):
        combination.append("".join(map(str, word_list[i])))
    return combination

# The main part of the game!
print("========== HANGMAN ==========")
while True:
    if chance == 0:
        print("Hangman died because of your wrong answers. Hope he will have a better life in the paradise. :)")
        break
    if combine(hangman) == targets:
        print("Congratulations! You saved Hangman!")
        break
    display_word(hangman)
    display_guessed(guessed)
    ans = get_guess()
    flag_rep = is_guessed(ans)
    if not flag_rep:
        flag_ayn = judgement(ans, targets)
        if flag_ayn is None:
            print("You have just entered nothing! Try again.")
        elif flag_ayn == False:
            chance -= 1
            print("Your guess is not right! Now you have " + str(chance) + " chance(s) left.")
        else:
            print("Your guess is right!")
            update(ans, hangman, targets)
    print()

# End
print("Hangman chose these words:")
for i in range(len(targets)):
    print(str(i + 1) + ". " + targets[i])
input()
