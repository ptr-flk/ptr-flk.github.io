# Hangman
import os

# Preparations
word = input("Hangman needs an English word: ")
word = word.upper()
chance = int(input("Number of wrong answers required for Hangman to die: "))
print()

# Print the information before the game starts
print("Information about " + word + ":")
print("Word length: " + str(len(word)))
print("Chances: " + str(chance))
input("Press any key to continue:")
os.system("cls")

# Create a list for the game
hangman = []
for i in range(len(word)):
    hangman.append("_")
result = ""

# The main part of the game
print("===== HANGMAN =====")
while True:
    if chance == 0:
        print("Hangman died because of your wrong answers. Hope he will have a better life in the paradise. :)")
        break
    if result == word:
        print("Congratulations! You saved Hangman!")
        break
    for i in hangman:
        print(i, end = " ")
    print()
    guess = input("Your guess (1 letter): ")
    guess = guess[0].upper()
    if guess in word:
        print("Your guess is right!")
        for i in range(len(word)):
            if guess == word[i]:
                hangman[i] = guess
    else:
        chance -= 1
        print("Your guess is not right! Now you have " + str(chance) + " chance(s) to guess.")
    result = "".join(map(str, hangman))
    print()
print('Hangman chose the word "' + word + '".')
input()
